# DEX Trading Platform - Visual Design System

## Design Philosophy

### Core Aesthetic Vision
**Futuristic DeFi Sophistication**: A cutting-edge visual language that embodies the innovative spirit of decentralized finance while maintaining professional credibility. The design balances technological advancement with financial trust, creating an interface that feels both revolutionary and reliable.

### Color Palette
**Primary Colors**:
- **Deep Space Navy**: #0B1426 (main background)
- **Electric Cyan**: #00D4FF (primary accent, trading indicators)
- **Neon Green**: #39FF14 (positive values, gains, success states)
- **Warm Amber**: #FF8C00 (warnings, pending states)

**Secondary Colors**:
- **Cosmic Purple**: #6366F1 (secondary accents, charts)
- **Silver Chrome**: #E5E7EB (text, borders)
- **Charcoal**: #1F2937 (card backgrounds, panels)
- **Crimson Red**: #EF4444 (losses, errors, alerts)

**Gradient Accents**:
- **Aurora Flow**: Linear gradient from #00D4FF to #6366F1 (hero backgrounds, highlights)
- **Plasma Glow**: Radial gradient from #39FF14 to transparent (success states)

### Typography
**Display Font**: "Orbitron" - Bold, futuristic sans-serif for headings and key metrics
- H1: 48px, font-weight: 900 (main titles)
- H2: 32px, font-weight: 700 (section headers)
- H3: 24px, font-weight: 600 (subsections)

**Body Font**: "Inter" - Clean, highly readable sans-serif for content and UI elements
- Body Large: 16px, font-weight: 400 (main content)
- Body Medium: 14px, font-weight: 400 (secondary content)
- Body Small: 12px, font-weight: 500 (labels, captions)

**Monospace Font**: "JetBrains Mono" - For numerical data, addresses, codes
- Data Display: 18px, font-weight: 600 (prices, amounts)
- Code/Text: 14px, font-weight: 400 (addresses, hashes)

### Visual Language
**Geometric Precision**: Clean lines, perfect circles, and angular elements that suggest blockchain technology and mathematical precision
**Depth & Layering**: Strategic use of shadows, blur effects, and transparency to create visual hierarchy
**Glowing Elements**: Subtle neon-style glows on interactive elements and key data points
**Particle Effects**: Floating geometric shapes and connection lines suggesting network topology

## Visual Effects & Styling

### Background Treatments
**Primary Background**: Animated starfield with subtle particle movement using p5.js
- Deep navy base with slowly moving white/cyan particles
- Parallax depth layers for immersion
- Subtle aurora-like color shifts at edges

**Card Backgrounds**: Semi-transparent panels with backdrop blur
- Background: rgba(31, 41, 55, 0.8)
- Backdrop-filter: blur(10px)
- Border: 1px solid rgba(229, 231, 235, 0.1)
- Border-radius: 16px

### Interactive Elements
**Buttons**:
- Primary: Gradient background with glow effect on hover
- Secondary: Transparent with colored border, fills on hover
- Icon buttons: Circular with subtle shadow and scale animation

**Form Elements**:
- Input fields: Dark backgrounds with cyan focus rings
- Dropdowns: Custom styled with smooth slide animations
- Sliders: Track with gradient fill and glowing handle

**Data Visualizations**:
- Charts: Custom color scheme with cyan and purple accents
- Progress bars: Gradient fills with animated loading
- Status indicators: Pulsing glows for active states

### Animation System
**Micro-Interactions**:
- Button hover: Scale(1.05) with glow expansion
- Card hover: Lift effect with increased shadow
- Loading states: Pulsing opacity with subtle rotation
- Success feedback: Brief scale animation with color flash

**Page Transitions**:
- Fade-in animations for content sections
- Staggered reveals for dashboard cards
- Smooth slide transitions between tabs
- Parallax scrolling for hero sections

**Data Animations**:
- Number counting animations for values
- Chart drawing animations on load
- Real-time price updates with smooth transitions
- Portfolio value changes with color-coded animations

### Header & Navigation Effects
**Navigation Bar**:
- Semi-transparent background with backdrop blur
- Active tab indicator with sliding underline
- Hover effects with subtle glow and scale
- Logo with subtle rotation animation

**Hero Section**:
- Animated background using shader-park for liquid-metal displacement
- Typewriter effect for main heading using Typed.js
- Floating geometric shapes with physics-based movement
- Gradient text effects with color cycling

### Scroll Motion Effects
**Reveal Animations**:
- Elements fade in when entering viewport (opacity 0.9 to 1.0)
- Subtle upward movement (16px translation)
- Staggered timing for card grids (100ms delays)
- Smooth easing curves for natural feel

**Parallax Elements**:
- Background particles move at different speeds
- Hero elements with subtle depth separation
- Decorative shapes with offset scroll speeds
- Maximum 8% translation to maintain readability

### Hover Effects
**Interactive Cards**:
- 3D tilt effect with perspective transform
- Enhanced glow and shadow expansion
- Content reveal with slide-up animations
- Color accent transitions

**Trading Interface Elements**:
- Token selection cards with border glow
- Chart elements with tooltip reveals
- Button states with gradient shifts
- Input fields with focus animations

### Advanced Visual Effects
**Particle Systems**:
- Floating connection lines between elements
- Subtle geometric shapes suggesting blockchain networks
- Interactive particle trails following cursor
- Ambient background movement

**Shader Effects**:
- Liquid displacement for hero backgrounds
- Fractal noise for texture overlays
- Chromatic aberration on text highlights
- Volumetric fog effects for depth

**Data Visualization Styling**:
- Custom ECharts.js themes with brand colors
- Animated chart reveals with drawing effects
- Interactive tooltips with smooth positioning
- Real-time data updates with transition animations

## Responsive Design Considerations
- Mobile-first approach with touch-friendly interactions
- Simplified animations for performance on mobile devices
- Adaptive typography scaling
- Flexible grid systems for different screen sizes

This design system creates a cohesive, futuristic aesthetic that positions the DEX platform as a cutting-edge financial tool while maintaining the professional credibility essential for financial applications.