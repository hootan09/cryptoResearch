// NexusDEX - Main JavaScript File
// Comprehensive functionality for DeFi trading platform

// Global variables and state
let isWalletConnected = false;
let currentAccount = null;
let priceUpdateInterval = null;
let chartUpdateInterval = null;

// Mock data for demonstration
const mockTokenData = {
    'ETH': { price: 3247.85, change: 4.08, color: '#FF6B35' },
    'USDC': { price: 1.00, change: 0.00, color: '#2775CA' },
    'WBTC': { price: 65234.89, change: 2.34, color: '#F7931A' },
    'LINK': { price: 18.47, change: 24.8, color: '#375BD2' },
    'DAI': { price: 1.00, change: 0.02, color: '#F59E0B' },
    'AAVE': { price: 234.56, change: 8.9, color: '#B6509E' },
    'USDT': { price: 1.00, change: -0.01, color: '#26A17B' },
    'MKR': { price: 3456.78, change: 5.67, color: '#1AAB9B' }
};

const mockPools = [
    { pair: 'ETH/USDC', tvl: 456.7, volume: 89.2, apy: 24.5, protocol: 'Uniswap V3', userShare: 0.12 },
    { pair: 'LINK/USDC', tvl: 234.5, volume: 45.6, apy: 31.2, protocol: 'SushiSwap', userShare: 0.08 },
    { pair: 'WBTC/ETH', tvl: 189.3, volume: 23.4, apy: 18.7, protocol: 'Curve Finance', userShare: 0.05 },
    { pair: 'AAVE/USDC', tvl: 123.4, volume: 34.5, apy: 28.3, protocol: 'Uniswap V3', userShare: 0.0 },
    { pair: 'USDT/USDC', tvl: 567.8, volume: 156.7, apy: 19.8, protocol: 'Curve Finance', userShare: 0.0 },
    { pair: 'MKR/ETH', tvl: 89.2, volume: 12.3, apy: 15.6, protocol: 'Balancer', userShare: 0.0 }
];

// Utility functions
function formatCurrency(amount, decimals = 2) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(amount);
}

function formatNumber(num, decimals = 2) {
    if (num >= 1e9) return (num / 1e9).toFixed(decimals) + 'B';
    if (num >= 1e6) return (num / 1e6).toFixed(decimals) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(decimals) + 'K';
    return num.toFixed(decimals);
}

function getChangeClass(change) {
    return change >= 0 ? 'price-positive' : 'price-negative';
}

function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const startTime = performance.now();
    
    function updateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth animation
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = start + (target - start) * easeOut;
        
        if (element.dataset.prefix === '$') {
            element.textContent = '$' + formatNumber(current);
        } else {
            element.textContent = formatNumber(current);
        }
        
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        }
    }
    
    requestAnimationFrame(updateCounter);
}

// Particle background system
function initParticleBackground() {
    if (typeof p5 === 'undefined') return;
    
    new p5((sketch) => {
        let particles = [];
        const numParticles = 100;
        
        sketch.setup = () => {
            const canvas = sketch.createCanvas(sketch.windowWidth, sketch.windowHeight);
            canvas.parent('particle-container');
            canvas.style('position', 'fixed');
            canvas.style('top', '0');
            canvas.style('left', '0');
            canvas.style('z-index', '-1');
            
            // Initialize particles
            for (let i = 0; i < numParticles; i++) {
                particles.push({
                    x: sketch.random(sketch.width),
                    y: sketch.random(sketch.height),
                    vx: sketch.random(-0.5, 0.5),
                    vy: sketch.random(-0.5, 0.5),
                    size: sketch.random(1, 3),
                    opacity: sketch.random(0.3, 0.8)
                });
            }
        };
        
        sketch.draw = () => {
            sketch.clear();
            
            // Update and draw particles
            particles.forEach(particle => {
                particle.x += particle.vx;
                particle.y += particle.vy;
                
                // Wrap around edges
                if (particle.x < 0) particle.x = sketch.width;
                if (particle.x > sketch.width) particle.x = 0;
                if (particle.y < 0) particle.y = sketch.height;
                if (particle.y > sketch.height) particle.y = 0;
                
                // Draw particle
                sketch.fill(0, 212, 255, particle.opacity * 255);
                sketch.noStroke();
                sketch.circle(particle.x, particle.y, particle.size);
            });
            
            // Draw connections
            particles.forEach((p1, i) => {
                particles.slice(i + 1).forEach(p2 => {
                    const distance = sketch.dist(p1.x, p1.y, p2.x, p2.y);
                    if (distance < 100) {
                        const alpha = sketch.map(distance, 0, 100, 0.3, 0);
                        sketch.stroke(0, 212, 255, alpha * 255);
                        sketch.strokeWeight(0.5);
                        sketch.line(p1.x, p1.y, p2.x, p2.y);
                    }
                });
            });
        };
        
        sketch.windowResized = () => {
            sketch.resizeCanvas(sketch.windowWidth, sketch.windowHeight);
        };
    });
}

// Scroll reveal animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.reveal-up').forEach(el => {
        observer.observe(el);
    });
}

// Counter animations
function initCounterAnimations() {
    const counters = document.querySelectorAll('.animate-counter');
    
    counters.forEach(counter => {
        const target = parseFloat(counter.dataset.target);
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(counter, target);
                    observer.unobserve(counter);
                }
            });
        });
        
        observer.observe(counter);
    });
}

// Navigation functionality
function initNavigation() {
    const connectWalletBtn = document.getElementById('connect-wallet');
    if (connectWalletBtn) {
        connectWalletBtn.addEventListener('click', connectWallet);
    }
}

function connectWallet() {
    // Simulate wallet connection
    isWalletConnected = true;
    currentAccount = '0x742d...8f9a';
    
    const connectBtn = document.getElementById('connect-wallet');
    if (connectBtn) {
        connectBtn.textContent = currentAccount;
        connectBtn.classList.add('bg-green-600', 'hover:bg-green-700');
        connectBtn.classList.remove('bg-gradient-to-r', 'from-cyan-500', 'to-purple-600');
    }
    
    // Update all wallet-dependent elements
    updateWalletConnectedState();
    
    // Show success notification
    showNotification('Wallet connected successfully!', 'success');
}

function updateWalletConnectedState() {
    const swapBtn = document.getElementById('swap-btn');
    if (swapBtn && isWalletConnected) {
        swapBtn.textContent = 'Swap Tokens';
        swapBtn.classList.remove('opacity-50');
    }
}

// Trading interface functionality
function initTradingInterface() {
    if (!document.getElementById('trading-chart')) return;
    
    initTokenDropdowns();
    initTradingChart();
    initPriceUpdates();
    initSwapFunctionality();
}

function initTokenDropdowns() {
    const fromTokenBtn = document.getElementById('from-token-btn');
    const toTokenBtn = document.getElementById('to-token-btn');
    const fromDropdown = document.getElementById('from-token-dropdown');
    const toDropdown = document.getElementById('to-token-dropdown');
    
    if (fromTokenBtn && fromDropdown) {
        fromTokenBtn.addEventListener('click', () => {
            fromDropdown.classList.toggle('hidden');
            toDropdown.classList.add('hidden');
        });
    }
    
    if (toTokenBtn && toDropdown) {
        toTokenBtn.addEventListener('click', () => {
            toDropdown.classList.toggle('hidden');
            fromDropdown.classList.add('hidden');
        });
    }
    
    // Handle token selection
    document.querySelectorAll('.token-option').forEach(option => {
        option.addEventListener('click', (e) => {
            const symbol = e.currentTarget.dataset.symbol;
            const name = e.currentTarget.dataset.name;
            selectToken(symbol, name, e.currentTarget.closest('.token-dropdown'));
        });
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.token-dropdown') && !e.target.closest('#from-token-btn') && !e.target.closest('#to-token-btn')) {
            fromDropdown?.classList.add('hidden');
            toDropdown?.classList.add('hidden');
        }
    });
}

function selectToken(symbol, name, dropdown) {
    const isFromDropdown = dropdown.id === 'from-token-dropdown';
    const btn = isFromDropdown ? document.getElementById('from-token-btn') : document.getElementById('to-token-btn');
    
    if (btn) {
        const tokenIcon = btn.querySelector('.w-8.h-8');
        const tokenSymbol = btn.querySelector('.font-medium');
        
        // Update token icon and symbol
        tokenIcon.className = `w-8 h-8 bg-${getTokenColor(symbol)}-500 rounded-full flex items-center justify-center text-white font-bold text-sm`;
        tokenIcon.textContent = symbol.charAt(0);
        tokenSymbol.textContent = symbol;
    }
    
    dropdown.classList.add('hidden');
    updateSwapCalculation();
}

function getTokenColor(symbol) {
    const colors = {
        'ETH': 'orange',
        'USDC': 'blue',
        'WBTC': 'yellow',
        'LINK': 'purple',
        'DAI': 'yellow',
        'AAVE': 'pink',
        'USDT': 'green',
        'MKR': 'red'
    };
    return colors[symbol] || 'gray';
}

function initTradingChart() {
    const chartElement = document.getElementById('trading-chart');
    if (!chartElement || typeof echarts === 'undefined') return;
    
    const chart = echarts.init(chartElement);
    
    // Generate mock candlestick data
    const data = generateCandlestickData();
    
    const option = {
        backgroundColor: 'transparent',
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: data.map(item => item[0]),
            axisLine: { lineStyle: { color: '#374151' } },
            axisLabel: { color: '#9CA3AF' }
        },
        yAxis: {
            type: 'value',
            scale: true,
            axisLine: { lineStyle: { color: '#374151' } },
            axisLabel: { color: '#9CA3AF' },
            splitLine: { lineStyle: { color: '#374151' } }
        },
        series: [{
            type: 'candlestick',
            data: data.map(item => [item[1], item[2], item[3], item[4]]),
            itemStyle: {
                color: '#39FF14',
                color0: '#EF4444',
                borderColor: '#39FF14',
                borderColor0: '#EF4444'
            }
        }],
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(31, 41, 55, 0.9)',
            borderColor: '#00D4FF',
            textStyle: { color: '#E5E7EB' }
        }
    };
    
    chart.setOption(option);
    
    // Handle timeframe changes
    document.querySelectorAll('.timeframe-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.timeframe-btn').forEach(b => {
                b.classList.remove('bg-cyan-500', 'text-white');
                b.classList.add('bg-gray-700', 'text-gray-300');
            });
            
            e.target.classList.remove('bg-gray-700', 'text-gray-300');
            e.target.classList.add('bg-cyan-500', 'text-white');
            
            // Update chart data based on timeframe
            const newData = generateCandlestickData(e.target.dataset.timeframe);
            chart.setOption({
                xAxis: { data: newData.map(item => item[0]) },
                series: [{ data: newData.map(item => [item[1], item[2], item[3], item[4]]) }]
            });
        });
    });
    
    // Resize chart on window resize
    window.addEventListener('resize', () => {
        chart.resize();
    });
}

function generateCandlestickData(timeframe = '1H') {
    const data = [];
    const basePrice = 3247.85;
    const now = new Date();
    
    let intervals, priceVolatility;
    switch (timeframe) {
        case '1H':
            intervals = 60;
            priceVolatility = 50;
            break;
        case '4H':
            intervals = 60;
            priceVolatility = 100;
            break;
        case '1D':
            intervals = 30;
            priceVolatility = 200;
            break;
        case '1W':
            intervals = 52;
            priceVolatility = 500;
            break;
        default:
            intervals = 60;
            priceVolatility = 50;
    }
    
    for (let i = 0; i < intervals; i++) {
        const time = new Date(now.getTime() - (intervals - i) * getTimeframeMs(timeframe));
        const timeStr = timeframe === '1W' ? 
            `W${i + 1}` : 
            time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        
        const open = basePrice + (Math.random() - 0.5) * priceVolatility;
        const close = open + (Math.random() - 0.5) * priceVolatility * 0.5;
        const high = Math.max(open, close) + Math.random() * priceVolatility * 0.3;
        const low = Math.min(open, close) - Math.random() * priceVolatility * 0.3;
        
        data.push([timeStr, open, close, low, high]);
    }
    
    return data;
}

function getTimeframeMs(timeframe) {
    const ms = {
        '1H': 60 * 1000,
        '4H': 4 * 60 * 1000,
        '1D': 24 * 60 * 60 * 1000,
        '1W': 7 * 24 * 60 * 60 * 1000
    };
    return ms[timeframe] || 60 * 1000;
}

function initPriceUpdates() {
    // Update prices every 5 seconds
    priceUpdateInterval = setInterval(updatePrices, 5000);
    updatePrices(); // Initial update
}

function updatePrices() {
    // Update current price display
    const currentPrice = document.getElementById('current-price');
    const priceChange = document.getElementById('price-change');
    
    if (currentPrice && priceChange) {
        const ethData = mockTokenData['ETH'];
        const newPrice = ethData.price + (Math.random() - 0.5) * 50;
        const change = (newPrice - ethData.price) / ethData.price * 100;
        
        currentPrice.textContent = `$${newPrice.toFixed(2)}`;
        priceChange.textContent = `${change >= 0 ? '+' : ''}$${Math.abs(change * newPrice / 100).toFixed(2)} (${change >= 0 ? '+' : ''}${change.toFixed(2)}%)`;
        priceChange.className = getChangeClass(change);
    }
    
    // Update order book
    updateOrderBook();
}

function updateOrderBook() {
    const currentPrice = parseFloat(document.getElementById('current-price')?.textContent.replace('$', '') || '3247.85');
    
    // Update buy/sell orders with realistic spread
    const buyOrders = document.querySelectorAll('.order-book-buy .jetbrains');
    const sellOrders = document.querySelectorAll('.order-book-sell .jetbrains');
    
    buyOrders.forEach((order, index) => {
        const price = currentPrice - (index + 1) * (0.01 + Math.random() * 0.05);
        order.textContent = price.toFixed(2);
    });
    
    sellOrders.forEach((order, index) => {
        const price = currentPrice + (index + 1) * (0.01 + Math.random() * 0.05);
        order.textContent = price.toFixed(2);
    });
}

function initSwapFunctionality() {
    const fromAmount = document.getElementById('from-amount');
    const toAmount = document.getElementById('to-amount');
    const swapBtn = document.getElementById('swap-btn');
    const swapDirection = document.getElementById('swap-direction');
    
    if (fromAmount) {
        fromAmount.addEventListener('input', updateSwapCalculation);
    }
    
    if (swapBtn) {
        swapBtn.addEventListener('click', executeSwap);
    }
    
    if (swapDirection) {
        swapDirection.addEventListener('click', () => {
            // Swap the tokens
            const fromBtn = document.getElementById('from-token-btn');
            const toBtn = document.getElementById('to-token-btn');
            
            if (fromBtn && toBtn) {
                const fromHtml = fromBtn.innerHTML;
                const toHtml = toBtn.innerHTML;
                
                fromBtn.innerHTML = toHtml;
                toBtn.innerHTML = fromHtml;
                
                updateSwapCalculation();
            }
        });
    }
}

function updateSwapCalculation() {
    const fromAmount = document.getElementById('from-amount');
    const toAmount = document.getElementById('to-amount');
    
    if (fromAmount && toAmount && fromAmount.value) {
        const amount = parseFloat(fromAmount.value);
        const rate = 3247.85; // Mock exchange rate
        toAmount.value = (amount * rate).toFixed(2);
    }
}

function executeSwap() {
    if (!isWalletConnected) {
        showNotification('Please connect your wallet first', 'warning');
        return;
    }
    
    showNotification('Swap executed successfully!', 'success');
    
    // Add to trade history
    addToTradeHistory();
}

function addToTradeHistory() {
    const historyTable = document.querySelector('table tbody');
    if (!historyTable) return;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour12: false });
    
    const newRow = document.createElement('tr');
    newRow.className = 'border-b border-gray-800';
    newRow.innerHTML = `
        <td class="py-4 text-gray-400">${timeStr}</td>
        <td class="py-4">
            <span class="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs">BUY</span>
        </td>
        <td class="py-4 text-white">ETH/USDC</td>
        <td class="py-4 text-white">${document.getElementById('from-amount')?.value || '0.5'} ETH</td>
        <td class="py-4 text-white jetbrains">$${document.getElementById('current-price')?.textContent.replace('$', '') || '3247.85'}</td>
        <td class="py-4">
            <span class="bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs">Pending</span>
        </td>
    `;
    
    historyTable.insertBefore(newRow, historyTable.firstChild);
}

// Portfolio functionality
function initPortfolioInterface() {
    if (!document.getElementById('performance-chart')) return;
    
    initPerformanceChart();
    initAllocationChart();
    initPortfolioTimeframes();
}

function initPerformanceChart() {
    const chartElement = document.getElementById('performance-chart');
    if (!chartElement || typeof echarts === 'undefined') return;
    
    const chart = echarts.init(chartElement);
    
    // Generate performance data
    const dates = [];
    const portfolioData = [];
    const ethData = [];
    const btcData = [];
    
    const now = new Date();
    for (let i = 30; i >= 0; i--) {
        const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
        dates.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        
        portfolioData.push(100000 + Math.random() * 30000 + i * 500);
        ethData.push(3000 + Math.random() * 500 + i * 10);
        btcData.push(60000 + Math.random() * 5000 + i * 50);
    }
    
    const option = {
        backgroundColor: 'transparent',
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: {
            type: 'category',
            data: dates,
            axisLine: { lineStyle: { color: '#374151' } },
            axisLabel: { color: '#9CA3AF' }
        },
        yAxis: {
            type: 'value',
            axisLine: { lineStyle: { color: '#374151' } },
            axisLabel: { color: '#9CA3AF' },
            splitLine: { lineStyle: { color: '#374151' } }
        },
        series: [
            {
                name: 'Portfolio',
                type: 'line',
                data: portfolioData,
                smooth: true,
                lineStyle: { color: '#00D4FF', width: 3 },
                areaStyle: {
                    color: {
                        type: 'linear',
                        x: 0, y: 0, x2: 0, y2: 1,
                        colorStops: [
                            { offset: 0, color: 'rgba(0, 212, 255, 0.3)' },
                            { offset: 1, color: 'rgba(0, 212, 255, 0.05)' }
                        ]
                    }
                }
            },
            {
                name: 'ETH',
                type: 'line',
                data: ethData,
                smooth: true,
                lineStyle: { color: '#6B7280', width: 2 }
            },
            {
                name: 'BTC',
                type: 'line',
                data: btcData,
                smooth: true,
                lineStyle: { color: '#6366F1', width: 2 }
            }
        ],
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(31, 41, 55, 0.9)',
            borderColor: '#00D4FF',
            textStyle: { color: '#E5E7EB' }
        },
        legend: {
            data: ['Portfolio', 'ETH', 'BTC'],
            textStyle: { color: '#9CA3AF' }
        }
    };
    
    chart.setOption(option);
    
    window.addEventListener('resize', () => {
        chart.resize();
    });
}

function initAllocationChart() {
    const chartElement = document.getElementById('allocation-chart');
    if (!chartElement || typeof echarts === 'undefined') return;
    
    const chart = echarts.init(chartElement);
    
    const data = [
        { value: 45.2, name: 'ETH', itemStyle: { color: '#FF6B35' } },
        { value: 23.8, name: 'USDC', itemStyle: { color: '#2775CA' } },
        { value: 18.5, name: 'LINK', itemStyle: { color: '#375BD2' } },
        { value: 12.5, name: 'WBTC', itemStyle: { color: '#F7931A' } }
    ];
    
    const option = {
        backgroundColor: 'transparent',
        series: [{
            type: 'pie',
            radius: ['40%', '70%'],
            center: ['50%', '50%'],
            data: data,
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 212, 255, 0.5)'
                }
            },
            label: {
                show: false
            },
            labelLine: {
                show: false
            }
        }],
        tooltip: {
            trigger: 'item',
            backgroundColor: 'rgba(31, 41, 55, 0.9)',
            borderColor: '#00D4FF',
            textStyle: { color: '#E5E7EB' },
            formatter: '{a} <br/>{b}: {c}% ({d}%)'
        }
    };
    
    chart.setOption(option);
    
    window.addEventListener('resize', () => {
        chart.resize();
    });
}

function initPortfolioTimeframes() {
    document.querySelectorAll('.timeframe-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Update active button
            document.querySelectorAll('.timeframe-btn').forEach(b => {
                b.classList.remove('bg-cyan-500', 'text-white');
                b.classList.add('bg-gray-700', 'text-gray-300');
            });
            
            e.target.classList.remove('bg-gray-700', 'text-gray-300');
            e.target.classList.add('bg-cyan-500', 'text-white');
            
            // Update chart data based on timeframe
            // This would typically fetch new data from an API
            showNotification(`Updated to ${e.target.dataset.timeframe} view`, 'info');
        });
    });
}

// Pools functionality
function initPoolsInterface() {
    if (!document.querySelector('.pool-card')) return;
    
    initPoolSorting();
    initPoolSearch();
}

function initPoolSorting() {
    document.querySelectorAll('.sort-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Update active button
            document.querySelectorAll('.sort-btn').forEach(b => {
                b.classList.remove('bg-cyan-500', 'text-white');
                b.classList.add('bg-gray-700', 'text-gray-300');
            });
            
            e.target.classList.remove('bg-gray-700', 'text-gray-300');
            e.target.classList.add('bg-cyan-500', 'text-white');
            
            // Sort pools
            sortPools(e.target.dataset.sort);
        });
    });
}

function sortPools(sortBy) {
    const poolContainer = document.querySelector('.grid.grid-cols-1.md\\:grid-cols-2.lg\\:grid-cols-3.gap-6');
    if (!poolContainer) return;
    
    const pools = Array.from(poolContainer.querySelectorAll('.pool-card'));
    
    pools.sort((a, b) => {
        switch (sortBy) {
            case 'apy':
                return parseFloat(b.querySelector('.font-bold').textContent) - parseFloat(a.querySelector('.font-bold').textContent);
            case 'tvl':
                return parseFloat(b.querySelector('.jetbrains').textContent.replace(/[$M]/g, '')) - parseFloat(a.querySelector('.jetbrains').textContent.replace(/[$M]/g, ''));
            case 'volume':
                const bVolume = b.querySelectorAll('.jetbrains')[1].textContent.replace(/[$M]/g, '');
                const aVolume = a.querySelectorAll('.jetbrains')[1].textContent.replace(/[$M]/g, '');
                return parseFloat(bVolume) - parseFloat(aVolume);
            default:
                return 0;
        }
    });
    
    // Re-append sorted pools
    pools.forEach(pool => poolContainer.appendChild(pool));
}

function initPoolSearch() {
    const searchInput = document.querySelector('input[placeholder="Search pools..."]');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const pools = document.querySelectorAll('.pool-card');
        
        pools.forEach(pool => {
            const pairName = pool.querySelector('h3').textContent.toLowerCase();
            if (pairName.includes(searchTerm)) {
                pool.style.display = 'block';
            } else {
                pool.style.display = 'none';
            }
        });
    });
}

function openAddLiquidity(pairName) {
    const modal = document.getElementById('add-liquidity-modal');
    const modalPairName = document.getElementById('modal-pair-name');
    
    if (modal && modalPairName) {
        modalPairName.textContent = pairName;
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }
}

function closeAddLiquidity() {
    const modal = document.getElementById('add-liquidity-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;
    
    const colors = {
        success: 'bg-green-600 text-white',
        warning: 'bg-yellow-600 text-white',
        error: 'bg-red-600 text-white',
        info: 'bg-cyan-600 text-white'
    };
    
    notification.className += ` ${colors[type]}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize core systems
    initParticleBackground();
    initScrollAnimations();
    initCounterAnimations();
    initNavigation();
    
    // Initialize page-specific functionality
    initTradingInterface();
    initPortfolioInterface();
    initPoolsInterface();
    
    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Initialize typewriter effect on homepage
    if (document.getElementById('typed-text') && typeof Typed !== 'undefined') {
        new Typed('#typed-text', {
            strings: [
                'Next-Generation DeFi Trading',
                'Advanced Portfolio Analytics',
                'Professional Liquidity Management',
                'Institutional-Grade Security'
            ],
            typeSpeed: 50,
            backSpeed: 30,
            backDelay: 2000,
            loop: true,
            showCursor: true,
            cursorChar: '|'
        });
    }
    
    console.log('NexusDEX platform initialized successfully');
});

// Cleanup intervals when page unloads
window.addEventListener('beforeunload', () => {
    if (priceUpdateInterval) clearInterval(priceUpdateInterval);
    if (chartUpdateInterval) clearInterval(chartUpdateInterval);
});

// Export functions for global access
window.NexusDEX = {
    connectWallet,
    openAddLiquidity,
    closeAddLiquidity,
    showNotification,
    formatCurrency,
    formatNumber
};